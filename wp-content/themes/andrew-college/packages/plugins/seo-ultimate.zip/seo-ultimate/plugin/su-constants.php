<?php

define('SU_MODULE_ENABLED', 10);
define('SU_MODULE_SILENCED', 5);
define('SU_MODULE_HIDDEN', 0);
define('SU_MODULE_DISABLED', -10);

define('SU_RESULT_OK', 1);
define('SU_RESULT_WARNING', 0);
define('SU_RESULT_ERROR', -1);

define('SU_AIOSP_PATH', 'all-in-one-seo-pack/all_in_one_seo_pack.php');
define('SU_PSP_PATH', 'platinum-seo-pack/platinum_seo_pack.php');
define('SU_YWS_PATH', 'wordpress-seo/wp-seo.php');

?>